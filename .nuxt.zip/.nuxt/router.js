import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6211ff6a = () => interopDefault(import('..\\pages\\features.vue' /* webpackChunkName: "pages_features" */))
const _abdfec50 = () => interopDefault(import('..\\pages\\features\\index.vue' /* webpackChunkName: "pages_features_index" */))
const _00e22dc1 = () => interopDefault(import('..\\pages\\features\\setting\\city.vue' /* webpackChunkName: "pages_features_setting_city" */))
const _66c2cba4 = () => interopDefault(import('..\\pages\\features\\setting\\control-level.vue' /* webpackChunkName: "pages_features_setting_control-level" */))
const _419f5b82 = () => interopDefault(import('..\\pages\\features\\setting\\pollutant-source-type.vue' /* webpackChunkName: "pages_features_setting_pollutant-source-type" */))
const _7649712a = () => interopDefault(import('..\\pages\\features\\setting\\reserves-type.vue' /* webpackChunkName: "pages_features_setting_reserves-type" */))
const _45b8974c = () => interopDefault(import('..\\pages\\features\\setting\\role.vue' /* webpackChunkName: "pages_features_setting_role" */))
const _3d235a8f = () => interopDefault(import('..\\pages\\features\\spatial-data\\air-quality.vue' /* webpackChunkName: "pages_features_spatial-data_air-quality" */))
const _0b1cf431 = () => interopDefault(import('..\\pages\\features\\spatial-data\\medical-waste.vue' /* webpackChunkName: "pages_features_spatial-data_medical-waste" */))
const _6e7be1a2 = () => interopDefault(import('..\\pages\\features\\spatial-data\\pollutant-source-enterprise.vue' /* webpackChunkName: "pages_features_spatial-data_pollutant-source-enterprise" */))
const _4f047064 = () => interopDefault(import('..\\pages\\features\\spatial-data\\radiation-source.vue' /* webpackChunkName: "pages_features_spatial-data_radiation-source" */))
const _e7bd3a1c = () => interopDefault(import('..\\pages\\features\\spatial-data\\soil-pollutant-area.vue' /* webpackChunkName: "pages_features_spatial-data_soil-pollutant-area" */))
const _ee84e26c = () => interopDefault(import('..\\pages\\features\\spatial-data\\surface-water.vue' /* webpackChunkName: "pages_features_spatial-data_surface-water" */))
const _4077b375 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/features",
    component: _6211ff6a,
    children: [{
      path: "",
      component: _abdfec50,
      name: "features"
    }, {
      path: "setting/city",
      component: _00e22dc1,
      name: "features-setting-city"
    }, {
      path: "setting/control-level",
      component: _66c2cba4,
      name: "features-setting-control-level"
    }, {
      path: "setting/pollutant-source-type",
      component: _419f5b82,
      name: "features-setting-pollutant-source-type"
    }, {
      path: "setting/reserves-type",
      component: _7649712a,
      name: "features-setting-reserves-type"
    }, {
      path: "setting/role",
      component: _45b8974c,
      name: "features-setting-role"
    }, {
      path: "spatial-data/air-quality",
      component: _3d235a8f,
      name: "features-spatial-data-air-quality"
    }, {
      path: "spatial-data/medical-waste",
      component: _0b1cf431,
      name: "features-spatial-data-medical-waste"
    }, {
      path: "spatial-data/pollutant-source-enterprise",
      component: _6e7be1a2,
      name: "features-spatial-data-pollutant-source-enterprise"
    }, {
      path: "spatial-data/radiation-source",
      component: _4f047064,
      name: "features-spatial-data-radiation-source"
    }, {
      path: "spatial-data/soil-pollutant-area",
      component: _e7bd3a1c,
      name: "features-spatial-data-soil-pollutant-area"
    }, {
      path: "spatial-data/surface-water",
      component: _ee84e26c,
      name: "features-spatial-data-surface-water"
    }]
  }, {
    path: "/",
    component: _4077b375,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
